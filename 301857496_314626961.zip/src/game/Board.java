package game;

public class Board {
	
	protected Player[][] board;
	
	protected int n, m;
	

	public Board(int n, int m)
	{
		board = new Player[n][m];
		
		this.n = n;
		this.m = m;		
	}
	
	protected boolean set(int i, int j, Player p)
	{
		boolean res;
		if(board[i][j] == null)
		{
			board[i][j] = p;
			
			res = true;
		}
		else
		{
			res = false;
		}
		
		return res;
	}
	
	public boolean isEmpty(int i, int j)
	{
		return (board[i][j] == null);
	}
	
	public Player get(int i, int j)
	{
		return board[i][j];
	}
	
	public boolean isFull()
	{
		for(int i = 0; i < n; i++)
		{
			for(int j = 0; j < m; j++)
			{
				if(board[i][j] == null)
				{
					return false;
				}			
			}
		}	
		return true;
	}
	
	@Override
	public String toString()
	{
		String S ="";
		for(int i = 0; i < n; i++)
		{
			for(int j = 0; j < m; j++)
			{
				if(board[i][j] == null)
				{
					S += ".";
				}
				else
				{
					S += board[i][j].getMark();
				}
			}
			
			S += "\n";
		}
		
		return S;
	}
	
	private int search(int i, int j, String dir, Player p)
	{
		int count = 0;
		switch(dir)
		{
		  case "East" :
		  {
			  if(j > (m - 1))
				  return count;
			  
			  if(board[i][j] == null)
				  return count;
			  
			  if((board[i][j].getMark() != p.getMark()))
				  return count;
			  
			  count += 1 + search(i,j+1,dir, p);
		  }
		  break;
		  
		  case "West" :
		  {
			  if(j < 0)
				  return count;
			  
			  if(board[i][j] == null)
				  return count;
			  
			  if(board[i][j].getMark() != p.getMark())
				  return count;
			  
			  count += 1 + search(i,j-1,dir, p);
		  }
	      break;
	      
		  case "North" :
		  {
			  if( i < 0)
				  return count;
			  
			  if(board[i][j] == null)
				  return count;
			  
			  if(board[i][j].getMark() != p.getMark())
				  return count;
			  count += 1 + search(i-1,j,dir, p);
		  }
	      break;
	      
		  case "South" :
		  {
			  if( i > (n - 1))
				  return count;
			  
			  if(board[i][j] == null)
				  return count;
			  
			  if(board[i][j].getMark() != p.getMark())
				  return count;
			  
			 count += 1 + search(i+1,j,dir, p);
		  }
	      break;
	      
		  case "SouthEast" :
		  {
			  if( (i > (n - 1)) || ( j > (m -1 )))
				  return count;
			  
			  if(board[i][j] == null)
				  return count;
			  
			  if(board[i][j].getMark() != p.getMark())
				  return count;
			  
			  count += 1 + search(i+1, j+1, dir, p);
		  }
		  break;
		  
		  case "SouthWest" :
		  {
			  if( (i > (n - 1)) || ( j < 0) )
		  		  return count;
			  
			  if(board[i][j] == null)
				  return count;
			  
			  if(board[i][j].getMark() != p.getMark())
				  return count;
			  
			  count += 1 + search(i+1, j-1, dir, p);
		  }
		  break;
		  
		  case "NorthEast" :
		  {
			  if( (i < 0) || ( j > (m -1 ) ))
		  		  return count;
			  
			  if(board[i][j] == null)
				  return count;
			  
			  if(board[i][j].getMark() != p.getMark())
				  return count;
			  
			  count += 1 + search(i-1, j+1, dir, p);
		  }
		  break;
		  
		  case "NorthWest" :
		  {
			  if( (i < 0) || ( j < 0 ))
		  		  return count;
			  
			  if(board[i][j] == null)
				  return count;
			  
			  if(board[i][j].getMark() != p.getMark())
				  return count;
			  
			  count +=  1 + search(i-1, j-1, dir, p);
		  }
		  break;
		  
		}
		
		return count;
	}
	
	protected int maxLineContaining(int i, int j)
	{
		int res = 1;
		
		int max = -1;
		
		
		
		res += search(i,j+1,"East", board[i][j]);
		res += search(i,j-1,"West", board[i][j]);
		max = (res > max ) ? res : max;
		
		res =1;
		res += search(i-1,j,"North", board[i][j]);
		res += search(i+1,j,"South", board[i][j]);
		max = (res > max ) ? res : max;
		
		res = 1;
		res += search(i+1,j+1,"SouthEast", board[i][j]);
		res += search(i+1,j-1,"SouthWest", board[i][j]);
		max = (res > max ) ? res : max;
		
		
		res = 1;
		res += search(i-1,j+1,"NorthEast", board[i][j]);
		res += search(i-1,j-1,"NorthWest", board[i][j]);
		max = (res > max ) ? res : max;
		
		return max;
	}

	
}
