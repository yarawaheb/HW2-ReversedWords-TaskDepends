package tree;

public class Node {
	private int count =0 ;
	private Node[] children = new Node['z'-'a'+1];


	public int num(String s) {
		int c=s.charAt(0)-'a';
		if(children[c]==null)return 0;
		if(s.length()==1) 
			return children[c].count;
		s=s.substring(1);
		return children[c].num(s);
		
	}
	
	public void add(String s) {		
		int c=s.charAt(0)-'a';
		if(children[c]==null)
			children[c]=new Node();
		if(s.length()==1) {
			children[c].count++;
			return;
		}
		s=s.substring(1);
		children[c].add(s);
	}
	
	
/*	public static void main(String[] args) {
		Node root= new Node();
		root.add("c");
		root.add("c");
		root.add("ab");
		root.add("az"); 
		root.add("azinyr"); 
		root.add("live"); 
		//root.add("azinyr");
		root.add("a"); 
		root.add("a"); 
		root.add("a");
		System.out.println(root.num("live"));
		System.out.println(root.num("a"));
		System.out.println(root.num("c"));
		System.out.println(root.num("azinyr"));

	}*/
}
