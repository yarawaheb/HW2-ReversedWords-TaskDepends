package tree;

import java.util.Scanner;

public class ReversedWords {

	public static int checkReversed() {
		int count=0;
		Node root=new Node();
		Scanner s=new Scanner(System.in);
		String str="",strRev;
		System.out.println("Enter strings one after one , X to exit : ");
		while(!str.equals("X")) {
			strRev="";
			str=s.next();
			if((!str.equals("X"))) {
			for(int i=str.length()-1;i>=0;i--)
				strRev+=str.charAt(i);
			if(root.num(strRev)>0)
				count++;
			root.add(str);
			}
		}
		return count;
	}
	
/*	public static void main(String[] args) {
		System.out.println(checkReversed());
	}*/
}
