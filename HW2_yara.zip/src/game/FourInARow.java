package game;

public class FourInARow extends Game{

	public FourInARow(String player1, String player2) {
		super(6, 7, new Player(player1, 'W'), new Player(player2, 'B'));
	}
	
	@Override
	protected boolean doesWin(int i, int j) {
		if (maxLineContaining(i, j)==4)return true;
		return false;
	}
	
	@Override
	protected boolean onePlay(Player p) {
		System.out.println(p.toString()+" enter col number : ");
		int col = s.nextInt(),k=-1;
		while( !super.isEmpty(0, col)) {
			System.out.println(p.toString()+" enter col number : ");
			col = s.nextInt();
		}
		for(int i=0;i<6;i++) {
			if(super.get(5-i, col)==null) {
				super.set(5-i, col, p);
				k=5-i;
				i=6;
			}
		}
		System.out.println(super.toString()+"\n");
		return doesWin(k, col);
		
		
	}
/*	public static void main(String[] args) {
	FourInARow g = new FourInARow("White", "Black");
	g.play();
	}*/

}
