package game;

import java.util.Scanner;

public class Game extends Board{
	protected Player[] players;
	protected Scanner s;
	protected boolean flag=false;

	
	public Game(int n, int m, Player p1, Player p2) {
		super(n,m);
		players=new Player[2];
		s=new Scanner(System.in);
		players[0]=p1;
		players[1]=p2;
	}
	
	protected boolean doesWin(int i, int j) {
		if(i==0 && j==0)return true;
		return false;
	}
	
	protected boolean onePlay(Player p) {
		System.out.println(p.toString()+ " enter your move : ");
		int i =s.nextInt();
		int j =s.nextInt();
		if(super.get(i, j)!=null) {
			System.out.println("There is a piece there already...\n");
			flag=true;
			}
		
		else super.set(i, j, p);
		System.out.println(super.toString()+"\n");
		return doesWin(i, j);
	}
	
	public Player play() {
		Player p=players[0];
		int count=0;
		while(!onePlay(p)) {
			if(!flag)
			count ++;
			else flag=false;
		if(super.isFull())return null;
		if(count%2==0)
			p=players[0];
		else p=players[1];
		}
		
		System.out.println(p.toString() +" won !");
		return p;

	}
	
/*	public static void main(String[] args) {
		Game g = new Game(3, 4, new Player("Red", 'R'), new Player("Black", 'B'));
		g.play();
		
		

	}*/
}
